package CommonFunctions;

import java.lang.reflect.Method;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

public class ListenerForAll implements ITestListener {
	
	public void onTestStart(ITestResult result) {
		//it will execute before each test method
		LaunchBrowser.logger.info(result.getName() +" testCase started");
		System.out.println(result.getName()+" testcase started");
		
	}
	
	public void onTestSuccess(ITestResult result) {
		System.out.println("-----------passed case ------------");

		System.out.println(result.getName()+" testCase passed");
	}
	public void onStart(ITestContext context,Method method,ITestResult result) {
		//it will execute before each Test tag

		LaunchBrowser.logger.info(context.getName()+" is started");
		System.out.println(context.getName() + " is  started");
	}

	public void onFinish(ITestContext context,Method method) {
		//it will execute after each  test Tag
		LaunchBrowser.logger.info(method.getName()+" is finished");
	}

}
