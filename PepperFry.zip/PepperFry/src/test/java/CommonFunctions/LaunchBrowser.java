package CommonFunctions;

import java.io.File;

import java.io.FileInputStream;

import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.aventstack.extentreports.reporter.configuration.ChartLocation;
import com.aventstack.extentreports.reporter.configuration.Theme;

public class LaunchBrowser extends BrowserManager{
	public static   Properties properties;
	public static WebDriver driver;
	public static ExtentTest test;
	public static ExtentHtmlReporter htmlReporter;
	public static ExtentReports extent;
	public static TakesScreenshot scrShot;
	public static  Logger logger;
	JavascriptExecutor js=(JavascriptExecutor)driver;
	public Properties loadPropertyFile() throws IOException
	{
		FileInputStream fis=new FileInputStream("C:\\Users\\Aashikha\\eclipse-workspace\\PepperFry\\src\\test\\resources\\config.properties");
		properties=new Properties();
		properties.load(fis);
		return properties;
	}
	@BeforeSuite
	public void launch() throws IOException
	{
		loadPropertyFile();
		String browser=properties.getProperty("browser");
		String url=properties.getProperty("url");

		driver=getDriver(browser);
		driver.manage().window().maximize();
		driver.get(url);

		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		htmlReporter=new ExtentHtmlReporter("C:\\Users\\Aashikha\\eclipse-workspace\\PepperFry\\target\\Report\\report.html");
		extent =new ExtentReports();
		extent.attachReporter(htmlReporter);
		//To add system or environment info by using the setSystemInfo method.
		extent.setSystemInfo("Host Name","Aashikha");
		extent.setSystemInfo("OS","Windows 11");
		extent.setSystemInfo("Browser","Chrome");
		extent.setSystemInfo("Java Version","1.8");
		extent.setSystemInfo("Maven Version","3.8");
		extent.setSystemInfo("TestNg Version","version 7.4.0");
		
		//configurations
		//add content, manage tests etc
		htmlReporter.config().setChartVisibilityOnOpen(true);
		htmlReporter.config().setDocumentTitle("Extent Report Demo");
		htmlReporter.config().setReportName("Test Report");
		htmlReporter.config().setTestViewChartLocation(ChartLocation.TOP);
		htmlReporter.config().setTheme(Theme.STANDARD);
		htmlReporter.config().setTimeStampFormat("EEEE, MMMM dd, yyyy, hh:mm a '('zzz')'");
		//property configurator
		PropertyConfigurator.configure("C:\\Users\\Aashikha\\eclipse-workspace\\PepperFry\\target\\Logs\\Log4jOutput\\log4jOutput.log");
	}
	//taking screen shot 
	public static void  Capture(String location) throws IOException
	{

	
		scrShot=((TakesScreenshot)driver);
		File source=scrShot.getScreenshotAs(OutputType.FILE);
		File dest=new File(location);
		FileUtils.copyFile(source, dest);
		test.addScreenCaptureFromPath(location);
		logger.info("Screenshot get captured successfully");
	}
	@AfterSuite
	public void tearDown() throws InterruptedException
	{
		extent.flush();
		TimeUnit.SECONDS.sleep(10);
		driver.quit();

	}
}
