package TestCases;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;

import CommonFunctions.LaunchBrowser;
import PageFactory.Furniture;
public class FurnitureModule extends LaunchBrowser {
	@Test
	public static void dressingTable() throws InterruptedException, IOException
	{
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		logger=Logger.getLogger(FurnitureModule.class.getName());
		logger.info("Furniture Module successfully started");
		logger.info("Dressing Table Test Case successfully started");
		PageFactory.initElements(driver,Furniture.class);
		JavascriptExecutor jse=(JavascriptExecutor)driver;
		Actions action=new  Actions(driver);
		//selecting furniture module
		TimeUnit.SECONDS.sleep(5);
		action.moveToElement(Furniture.furniture).build().perform();
		//selecting dressing table
		TimeUnit.SECONDS.sleep(5);
		jse.executeScript("arguments[0].click()", Furniture.dressingTable);
		TimeUnit.SECONDS.sleep(5);
		//filter furnitures using brand
		TimeUnit.SECONDS.sleep(5);
		jse.executeScript("arguments[0].click()",Furniture.brand);
		//filter using price range
		TimeUnit.SECONDS.sleep(5);
		jse.executeScript("arguments[0].click()",Furniture.priceRange);
		//filtering using price range
		TimeUnit.SECONDS.sleep(10);
		jse.executeScript("arguments[0].click()", Furniture.discount);
		//selecting the dressing table after filters
		TimeUnit.SECONDS.sleep(10);
		//driver.navigate().refresh();
		action.moveToElement(Furniture.table).build().perform();
		//adding dressing table to cart
		//driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		TimeUnit.SECONDS.sleep(5);
		jse.executeScript("arguments[0].click()", Furniture.addToCart1);
		//Furniture.addToCart.click();
		test=extent.createTest("verifying filters for Dressing Table");
		test.log(Status.PASS,"adding decors to cart");
		//taking screen shot after the items are added into cart
		Capture(properties.getProperty("screenShotLocation")+"//dressingTable.png");
		logger.info("Dressing Table Test Case successfully executed");
		logger.info("Dressing Table Module executed successfully");
	}
}
