package TestCases;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;

import CommonFunctions.LaunchBrowser;
import PageFactory.Login;
import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;

public class LoginModule extends LaunchBrowser {
//	public static void login()
//	{
	public String username1,pass;
	public static String arr1[][]= null;
	public static int i=1;
	// Method for passing the fetched data from excel file to test 
	@DataProvider(name="LoginData")
	public    String[][] Login_Credentials()throws BiffException, IOException
	{
		// Call readExcel method
		arr1 = readExcel();
		return arr1;
	}
	//Method for Fetch Data from Excel File
	public   String[][] readExcel()throws BiffException, IOException
	{
		FileInputStream file = new FileInputStream("C:\\Users\\Aashikha\\eclipse-workspace\\PepperFry\\src\\test\\resources\\pepperfrylogin.xls");
		Workbook workbook1 = Workbook.getWorkbook(file);
		Sheet sheet1 = workbook1.getSheet(0);
		int row_Count = sheet1.getRows();
		int column_Count = sheet1.getColumns();
		String arr2[][] = new String[row_Count][column_Count];
		for(int i = 0;i<row_Count;i++)
		{
			for(int j=0;j<column_Count;j++)
			{

				arr2[i][j]= sheet1.getCell(j,i).getContents();

			}
		}
		return arr2;
	}
	@Test(dataProvider="LoginData")
	public  void LoginCheck_Combinations(String username1, String pass) throws IOException, InterruptedException
	{
		logger=Logger.getLogger(LaunchBrowser.class.getName());
		logger.info("Driver got launched successfully");
		logger.info("Browser got launched successfully");

		driver.navigate().to("https://www.pepperfry.com/");
		PageFactory.initElements(driver,Login.class);
		JavascriptExecutor jse=(JavascriptExecutor)driver;
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Actions action=new  Actions(driver);
		action.moveToElement(Login.profile).build().perform();
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		jse.executeScript("arguments[0].click()", Login.profile);
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		jse.executeScript("arguments[0].click()",Login.Register);
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		jse.executeScript("arguments[0].click()", Login.login);
		Login.un.sendKeys(username1);
		if(username1.equals("aashikham3@gmail.com"))
		{
			if(pass.equals("Aashikha@3"))

			{

				driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
				Login.password.sendKeys("Aashikha@3");
				driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
				Login.submit.click();
				TimeUnit.SECONDS.sleep(5);
				test=extent.createTest("Verify Login"+i);
				// Testcase for Valid Email id and password
				test.log(Status.PASS,"Login page is opened successfully ");
				i++;
				Capture(properties.getProperty("screenShotLocation")+"//correctLogin.png");
			}
			else
			{
				// Testcase for Valid Email id and Invalid password
				test=extent.createTest("Verify Login"+i);
				test.log(Status.FAIL,"Valid Email id but Invalid password ");
				i++;
				Capture(properties.getProperty("screenShotLocation")+"//ValidEmailidbutInvalidpassword.png");
			}
		}
		//Execute Whether Email id is Invalid
		else {
			// Testcase for Invalid Email id and password
			test=extent.createTest("Verify login"+i);
			test.log(Status.FAIL,"Invalid Email id");
			i++;
			Capture(properties.getProperty("screenShotLocation")+"//InvalidEmailid.png");
		}	
	}
	//}
}
