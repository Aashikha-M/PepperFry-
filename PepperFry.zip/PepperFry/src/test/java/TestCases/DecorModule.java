package TestCases;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;

import CommonFunctions.LaunchBrowser;
import PageFactory.Decor;
import PageFactory.Furniture;
import PageFactory.Living;

public class DecorModule extends LaunchBrowser{
	@Test
	public static void birdHouses() throws IOException, InterruptedException
	{
		
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		logger=Logger.getLogger(DecorModule.class.getName());
		logger.info("Decor Module successfully started");
		logger.info("Bird Houses Test Case successfully started");
		PageFactory.initElements(driver,Decor.class);
		JavascriptExecutor jse=(JavascriptExecutor)driver;
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Actions action=new  Actions(driver);
		
		//mouse haver @ Decor
		TimeUnit.SECONDS.sleep(5);
		action.moveToElement(Decor.decor).build().perform();
		//selecting bird houses
		TimeUnit.SECONDS.sleep(5);
		jse.executeScript("arguments[0].click()",Decor.birdHouses);
		//filter with discount
		TimeUnit.SECONDS.sleep(5);
		jse.executeScript("arguments[0].click()", Decor.discount);
		//selecting cuckoo house
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		action.moveToElement(Decor.cuckooHouse).build().perform();
		//add to cart
		//driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		TimeUnit.SECONDS.sleep(5);
		jse.executeScript("arguments[0].click()",Decor.addToCart);
		test=extent.createTest("verifying filters for decors");
		test.log(Status.PASS,"Adding decors to cart");
		//taking screen shot after the items are added into cart
		Capture(properties.getProperty("screenShotLocation")+"//Decor.png");
		logger.info("Bird Houses Test Case successfully executed");
		logger.info("Decor Module executed successfully");
	}

}

