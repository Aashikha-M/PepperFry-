package TestCases;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;

import CommonFunctions.LaunchBrowser;
import PageFactory.Lighting;
import PageFactory.Living;

public class LightingModule extends LaunchBrowser {
	@Test
	public static void gateLights() throws IOException, InterruptedException
	{
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		logger=Logger.getLogger(LightingModule.class.getName());
		logger.info("Lighting Module successfully started");
		logger.info("Gate Light Test Case successfully started");
		PageFactory.initElements(driver,Lighting.class);
		JavascriptExecutor jse=(JavascriptExecutor)driver;
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Actions action=new  Actions(driver);

		//mouse haver @ Lighting
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		action.moveToElement(Lighting.lighting).build().perform();
		//selecting gate lights
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		jse.executeScript("arguments[0].click()",Lighting.gateLights);
		//filter with discount
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		jse.executeScript("arguments[0].click()", Lighting.discount);
		//selecting a product
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		action.moveToElement(Lighting.moonLight).build().perform();
		//add to cart
		TimeUnit.SECONDS.sleep(5);
		jse.executeScript("arguments[0].click()",Lighting.addToCart2);
		test=extent.createTest("verifying filters for Gate Light");
		test.log(Status.PASS,"Adding Gate Light to cart");
		//taking screen shot after the items are added into cart
		Capture(properties.getProperty("screenShotLocation")+"//gateLight.png");
		logger.info("Gate Light Test Case successfully executed");
		logger.info("Lighting Module executed successfully");
	}

}
