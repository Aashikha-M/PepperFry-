package TestCases;

import java.io.IOException;

import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;
import com.aventstack.extentreports.Status;
import CommonFunctions.LaunchBrowser;
import PageFactory.ModularFurniture;

public class ModularFurnitureModule extends LaunchBrowser {
	@Test
	public static void wardrobe() throws IOException, InterruptedException
	{
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		logger=Logger.getLogger(ModularFurnitureModule .class.getName());
		logger.info("Modular Furniture successfully started");
		logger.info("Wardrobe Test Case successfully started");
		PageFactory.initElements(driver,ModularFurniture.class);
		JavascriptExecutor jse=(JavascriptExecutor)driver;
		Actions action=new  Actions(driver);
		//mouse hover at Furnishings
		TimeUnit.SECONDS.sleep(5);
		action.moveToElement(ModularFurniture.modularFurniture).build().perform();
		//selecting Wardrobes
		TimeUnit.SECONDS.sleep(5);
		jse.executeScript("arguments[0].click()",ModularFurniture.wardrobe);
		//selecting Wardrobes with dressing table
		TimeUnit.SECONDS.sleep(5);
		jse.executeScript("arguments[0].click()",ModularFurniture.wardrobeTable);
		//viewing wardrobes in different poses
		TimeUnit.SECONDS.sleep(5);
		jse.executeScript("arguments[0].click()",ModularFurniture.pose1);
		TimeUnit.SECONDS.sleep(5);
		jse.executeScript("arguments[0].click()",ModularFurniture.pose2);
		test=extent.createTest("Verifying Add to cart button is present");
		test.log(Status.FAIL,"Add to cart button is missing");
		//taking screen shot after the items are Wish Listed
		Capture(properties.getProperty("screenShotLocation")+"//Wardrobe.png");
		logger.info("Wardrobe Test Case successfully executed");
		logger.info("Modular Furniture Module executed successfully");	
	}

}
