package TestCases;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;

import CommonFunctions.LaunchBrowser;
import PageFactory.Living;

public class LivingModule extends LaunchBrowser {
	@Test
	public static void lights() throws IOException
	{
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		logger=Logger.getLogger(LivingModule.class.getName());
		logger.info("Living Module successfully started");
		logger.info("Lights Test Case successfully started");
		PageFactory.initElements(driver,Living.class);
		//Mouse Hover at Living Module
		JavascriptExecutor jse=(JavascriptExecutor)driver;
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Actions action=new  Actions(driver);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		action.moveToElement(Living.living).build().perform();
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		jse.executeScript("arguments[0].click()",Living.Chandeliers);
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		//filtering chandliers using type
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		jse.executeScript("arguments[0].click()",Living.ChandeliersType);
		
		//filtering with color
		 //jse.executeScript("window.scrollBy(0,1000)");
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		jse.executeScript("arguments[0].scrollIntoView(true);",  Living.multiColor);
		jse.executeScript("arguments[0].click()",Living.multiColor);
		//add to cart
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		action.moveToElement(Living.addToCartOver).build().perform();
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		jse.executeScript("arguments[0].click()",Living.addToCart);
		test=extent.createTest("verifying filters for Light");
		test.log(Status.PASS,"Adding Gate Lights to cart");
		//taking screen shot after the items are added into cart
		Capture(properties.getProperty("screenShotLocation")+"//Light.png");
		logger.info("Lights Test Case successfully executed");
		logger.info("Living Module executed successfully");
	}

}
