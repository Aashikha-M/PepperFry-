package TestCases;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;

import CommonFunctions.LaunchBrowser;
import PageFactory.BedRoom;
import PageFactory.Furnishings;

public class FurnishingsModule extends LaunchBrowser {
	@Test
	public static void Organizers() throws InterruptedException, IOException
	{
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		logger=Logger.getLogger(FurnishingsModule.class.getName());
		logger.info("Furnishings successfully started");
		logger.info("Organizers Test Case successfully started");
		PageFactory.initElements(driver,Furnishings.class);
		JavascriptExecutor jse=(JavascriptExecutor)driver;
		//
		Actions action=new  Actions(driver);
		//mouse hover at Furnishings
		TimeUnit.SECONDS.sleep(5);
		action.moveToElement(Furnishings.Furnishings1).build().perform();
		//selecting organizers
		TimeUnit.SECONDS.sleep(5);
		jse.executeScript("arguments[0].click()",Furnishings.organisers);
		//Filtering with Brand
		TimeUnit.SECONDS.sleep(5);
		jse.executeScript("arguments[0].click()",Furnishings.brand);
		//Filtering with color
		TimeUnit.SECONDS.sleep(5);
		jse.executeScript("arguments[0].click()",Furnishings.color);
		//Filtering with type
		TimeUnit.SECONDS.sleep(5);
		jse.executeScript("arguments[0].click()",Furnishings.lid);
		//add to cart
		TimeUnit.SECONDS.sleep(5);
		action.moveToElement(Furnishings.add).build().perform();
		TimeUnit.SECONDS.sleep(5);
		jse.executeScript("arguments[0].click()",Furnishings.addToCart);
		test=extent.createTest("verifying filters for Organizers");
		test.log(Status.PASS,"adding Organizers to cart");
		//taking screen shot after the items are added into cart
		Capture(properties.getProperty("screenShotLocation")+"//Organizers.png");
		logger.info("Organizers Test Case successfully executed");
		logger.info("Furnishings  Module executed successfully");
	}

}
