package TestCases;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;

import CommonFunctions.LaunchBrowser;
import PageFactory.Appliances;
import PageFactory.Furnishings;

public class AppliancesModule extends LaunchBrowser {
	@Test
	public static void airConditioners() throws IOException, InterruptedException
	{
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		logger=Logger.getLogger(AppliancesModule .class.getName());
		logger.info("Appliances successfully started");
		logger.info("Ac Test Case successfully started");
		PageFactory.initElements(driver,Appliances.class);
		JavascriptExecutor jse=(JavascriptExecutor)driver;
		//
		Actions action=new  Actions(driver);
		//mouse hover at Furnishings
		TimeUnit.SECONDS.sleep(5);
		action.moveToElement(Appliances.Appliance).build().perform();
		TimeUnit.SECONDS.sleep(5);
		//selecting Air Conditioners
		TimeUnit.SECONDS.sleep(5);
		jse.executeScript("arguments[0].click()",Appliances.airConditioners);
		//Filtering with Brand
		TimeUnit.SECONDS.sleep(5);
		jse.executeScript("arguments[0].click()",Appliances.haier);
		//Filtering with discount
		TimeUnit.SECONDS.sleep(5);
		jse.executeScript("arguments[0].click()",Appliances.discount);
		//making ac as wishlist
		TimeUnit.SECONDS.sleep(5);
		jse.executeScript("arguments[0].click()",Appliances.wishList);
		//displaying wish list items
		TimeUnit.SECONDS.sleep(5);
		jse.executeScript("arguments[0].click()",Appliances.wishListShow);
		test=extent.createTest("verifying filters for AirConditioners");
		test.log(Status.SKIP,"Making ac to wishlist");
		//taking screen shot after the items are Wish Listed
		Capture(properties.getProperty("screenShotLocation")+"//AirConditioners.png");
		logger.info("AirConditioners Test Case successfully executed");
		logger.info("Appliances  Module executed successfully");




	}

}
