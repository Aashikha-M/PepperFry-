package TestCases;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;

import CommonFunctions.LaunchBrowser;
import PageFactory.BedRoom;
import PageFactory.KidsRoom;
import PageFactory.Living;

public class BedRoomModule extends LaunchBrowser {
	@Test
	public static void kingSizeBed() throws IOException, InterruptedException
	{
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		logger=Logger.getLogger(LivingModule.class.getName());
		logger.info("Bed Room Module successfully started");
		logger.info("King Size Bed Test Case successfully started");
		PageFactory.initElements(driver,BedRoom.class);
		JavascriptExecutor jse=(JavascriptExecutor)driver;
		//
		Actions action=new  Actions(driver);
		//mouse hover at kidsRoom
		//TimeUnit.SECONDS.sleep(5);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		action.moveToElement(BedRoom.bedRoom).build().perform();
		//selecting king size bed
		TimeUnit.SECONDS.sleep(5);
		jse.executeScript("arguments[0].click()",BedRoom.kingBed);
		//Filtering with Brand
		TimeUnit.SECONDS.sleep(5);
		jse.executeScript("arguments[0].click()",BedRoom.brand);
		//filtering using price range
		TimeUnit.SECONDS.sleep(5);
		jse.executeScript("arguments[0].click()",BedRoom.price);
		//add to cart
		TimeUnit.SECONDS.sleep(5);
		action.moveToElement(BedRoom.bedsHover).build().perform();
		TimeUnit.SECONDS.sleep(5);
		jse.executeScript("arguments[0].click()",BedRoom.cart);
		test=extent.createTest("verifying filters for King Size Bed");
		test.log(Status.PASS,"adding King Size Bed to cart");
		//taking screen shot after the items are added into cart
		Capture(properties.getProperty("screenShotLocation")+"//kingBed.png");
		logger.info("King Size Bed Test Case successfully executed");
		logger.info("Bed Room Module executed successfully");

	}

}
