package TestCases;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;

import CommonFunctions.LaunchBrowser;
import PageFactory.Furniture;
import PageFactory.KidsRoom;

public class KidsRoomModule extends LaunchBrowser {
	@Test
	public static void sofa() throws IOException, InterruptedException
	{
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		logger=Logger.getLogger(KidsRoomModule.class.getName());
		logger.info("Kids Room Module successfully started");
		logger.info("sofa Test Case successfully started");
		PageFactory.initElements(driver,KidsRoom.class);
		JavascriptExecutor jse=(JavascriptExecutor)driver;
		Actions action=new  Actions(driver);
		//mouse hover at kidsRoom
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		action.moveToElement(KidsRoom.kidsroom).build().perform();
		//selecting kids sofa
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		jse.executeScript("arguments[0].click()", KidsRoom.sofa);
		
		//filtering  sofa
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		action.moveToElement(KidsRoom.product).build().perform();
		
		//jse.executeScript("window.scroll(0,450)", "");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		action.moveToElement(KidsRoom.kids).build().perform();
		TimeUnit.SECONDS.sleep(5);
		jse.executeScript("arguments[0].click()",KidsRoom. addToCart);
		test=extent.createTest("verifying filters for sofa");
		test.log(Status.PASS,"Adding sofa to cart");
		//taking screen shot after the items are added into cart
		Capture(properties.getProperty("screenShotLocation")+"//sofa.png");
		logger.info("sofa Test Case successfully executed");
		logger.info("Kids Room Module executed successfully");
	}

}
