package MainClass;

import java.io.IOException;



import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.beust.jcommander.Parameter;

import CommonFunctions.LaunchBrowser;
import PageFactory.Furnishings;
import TestCases.AppliancesModule;
import TestCases.BedRoomModule;
import TestCases.DecorModule;
import TestCases.FurnishingsModule;
import TestCases.FurnitureModule;
import TestCases.KidsRoomModule;
import TestCases.LightingModule;
import TestCases.LivingModule;
import TestCases.LoginModule;
import TestCases.ModularFurnitureModule;
import jxl.read.biff.BiffException;

public class MainClass extends LaunchBrowser {
	

	public void allTests() throws IOException, InterruptedException
	{
		
			LivingModule.lights();
			DecorModule.birdHouses();
			LightingModule.gateLights();
			FurnitureModule.dressingTable();
			BedRoomModule.kingSizeBed();
			FurnishingsModule.Organizers();
			AppliancesModule.airConditioners();
			ModularFurnitureModule.wardrobe();
			KidsRoomModule.sofa();
	}
}
