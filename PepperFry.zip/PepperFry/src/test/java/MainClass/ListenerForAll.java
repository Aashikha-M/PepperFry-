package MainClass;
import java.lang.reflect.Method;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

import listener.GetLog4j;

public class ListenerForAll implements ITestListener {
	public void onTestStart(ITestResult result) {
		//it will execute before each test method
		GetLog4j.logs.info(result.getName() +" testCase started");
		System.out.println(result.getName()+" testcase started");
		
	}

	public void onTestSuccess(ITestResult result) {
		System.out.println("-----------passed case ------------");

		System.out.println(result.getName()+" testCase passed");
	}

	public void onTestFailure(ITestResult result) {
	}

	public void onTestSkipped(ITestResult result) {
	}

	public void onTestFailedButWithinSuccessPercentage(ITestResult result) {
	}

	public void onTestFailedWithTimeout(ITestResult result) {
		
	}

	public void onStart(ITestContext context,Method method,ITestResult result) {
		//it will execute before each Test tag

		GetLog4j.logs.info(context.getName()+" is started");
		System.out.println(context.getName() + " is  started");
	}

	public void onFinish(ITestContext context,Method method) {
		//it will execute after each  test Tag
		GetLog4j.logs.info(method.getName()+" is finished");
	}

}
