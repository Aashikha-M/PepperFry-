package PageFactory;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class BedRoom {
	@FindBy(linkText  ="Bedroom")
	public static WebElement bedRoom;
	//selecting king size bed
	@FindBy(xpath="/html[1]/body[1]/div[2]/header[1]/div[3]/div[1]/div[1]/div[2]/div[2]/div[1]/div[1]/div[1]/div[2]/div[3]/div[1]/div[1]/div[2]/div[4]/a[1]")
	public static WebElement kingBed;
	//Filtering with Brand
	@FindBy(xpath="//label[@for='brandsnameWoodsworth']")
	public static WebElement brand;
	//filtering using price range
	@FindBy(xpath="//label[@for='price0-30000']")
	public static WebElement price;
	//add to cart
	@FindBy(xpath="//img[@alt='Cicero Solid Wood King Size Bed in Acacia Natural Finish']")
	public static WebElement bedsHover;
	@FindBy(xpath="/html[1]/body[1]/div[2]/div[2]/div[1]/div[4]/div[3]/div[1]/div[2]/div[1]/div[1]/div[1]/div[3]/div[1]/div[1]/div[1]/a[1]")
	public static WebElement cart;
}
