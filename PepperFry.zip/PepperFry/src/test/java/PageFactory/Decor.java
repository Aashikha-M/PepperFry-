package PageFactory;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class Decor {
	//mouse haver @ Decor
	@FindBy(xpath="//li[7]//a[text()='Decor']")
	public static WebElement decor;
	//selecting bird houses
	@FindBy(xpath="//div//a[text()='Bird Houses']")
	public static WebElement birdHouses ;
	@FindBy(xpath="//li//label[text()='10% and Above']")
	public static WebElement discount;
	//selecting cuckoo house
	@FindBy(xpath="//img[@alt='Brown Terracotta Cuckoo Family Handmade Bird House']")
	public static WebElement cuckooHouse;
	//add to cart
	@FindBy(xpath="/html[1]/body[1]/div[2]/div[2]/div[1]/div[4]/div[3]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/a[1]")//div[@class='row clip-prod-container']//div[@id='p_7_1_1766810']//div//div[1]//a[text()='Add To Cart']")
	public static WebElement addToCart;

}
