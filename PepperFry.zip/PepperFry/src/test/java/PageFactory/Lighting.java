package PageFactory;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class Lighting {
	//mouse hover at lighting
	@FindBy(xpath="//li[8]//a[text()='Lighting']")
	public static WebElement lighting;
	//selecting gate lights
	@FindBy(xpath ="//*[@id=\"meta-lighting\"]/div/div[5]/div[2]/div[1]/a")
	public static WebElement gateLights;
	//filter with discount
	@FindBy(xpath="//label[@for='discount_percentage10-0']")//li//label[text()='Metal']
	public static WebElement discount;
	//selecting cuckoo house
	@FindBy(xpath="//a//img[@alt='Grey Metal Wall Light']")
	public static WebElement moonLight;
	//add to cart
	@FindBy(xpath="/html[1]/body[1]/div[2]/div[2]/div[1]/div[4]/div[3]/div[1]/div[2]/div[1]/div[1]/div[1]/div[30]/div[1]/div[1]/div[1]/a[1]")
	public static WebElement addToCart2;
	//div[@class='row clip-prod-container']//div[@id='p_15_1_1902011']//div//div[1]//a[text()='Add To Cart']"
	//div[@id='p_29_1_1902011']//a[@class='clip-add-to-cart-btn'][normalize-space()='Add To Cart']
	//div[@class='row clip-prod-container']//div[@id='p_15_1_1902011']//div//div[1]//a[text()='Add To Cart']
	//*[@id=\"p_29_1_1902011\"]/div/div[1]/div/a
	//html[1]/body[1]/div[2]/div[2]/div[1]/div[4]/div[3]/div[1]/div[2]/div[1]/div[1]/div[1]/div[30]/div[1]/div[1]/div[1]/a[1]
}
