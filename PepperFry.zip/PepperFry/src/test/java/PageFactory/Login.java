package PageFactory;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class Login  {
	//mouse hover at login
	@FindBy(xpath = "//a//span[2][text()='Profile']")
	public static WebElement profile;

	@FindBy(xpath="//a//b")
	public static WebElement Register;
	//*[@id="regPopUp"]/div/div[2]/div[2]/div[1]/a

	@FindBy(xpath = "//*[@id=\"regPopUp\"]/div/div[2]/div[2]/div[1]/a")//*[@id="regPopUp"]/div/div[2]/div[2]/div[1]/a
	public static WebElement login;//a[@class='reg-modal-right-bottom-btn font-13 pf-orange-color reg-modal-right-existing-btn']

	@FindBy(name="user[new]")
	public static WebElement un;

	@FindBy(id="password")
	public static WebElement password;
	
	@FindBy(id="formSubmit-popup_login_username_form")
	public static WebElement submit;

	//		@FindBy(xpath="//a[text()='Login using OTP']")//a[text()='Login using OTP']
	//		public static WebElement LoginOTP;

	//		@FindBy(xpath="//input[@id='loginMobile']")
	//		public static WebElement mobile;
	//		
	//		@FindBy(id="password")
	//		public static WebElement password;
	//		
	//		@FindBy(id="formSubmit-popup_login_username_form")//xpath=\"//a[text()='Get OTP']
	//		public static WebElement getOTP;
	//		
	////		@FindBy(xpath="//*[@id='loginOTPverify']")
	////		public static WebElement verifyOTP;


}
