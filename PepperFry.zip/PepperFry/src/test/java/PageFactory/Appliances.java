package PageFactory;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class Appliances {
	@FindBy(xpath = "//ul//li[9]//a[text()='Appliances']")
	public static WebElement Appliance;
	@FindBy(xpath = "//a[normalize-space()='Air Conditioners']")
	public static WebElement airConditioners;
	@FindBy(xpath="//label[@for='brandsnameHaier']")
	public static WebElement haier;
	@FindBy(xpath="//label[@for='discount_percentage40-0']")
	public static WebElement discount;
	@FindBy(xpath="//div[@class='clip-prd-hrt pf-col xs-2']")
	public static WebElement wishList;
	@FindBy(xpath="//*[@id=\"headerUserArea\"]/div[2]/div/div[2]/div[2]/a/span[1]/span")
	public static WebElement wishListShow;
	//a[@class='wishlist_bar active']//span[@class='header-nav-icon']
}
