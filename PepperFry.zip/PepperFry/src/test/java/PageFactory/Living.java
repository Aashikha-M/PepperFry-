package PageFactory;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class Living {
	//Mouse Hover at Living Module
	@FindBy(xpath ="//ul//li[2]//a[text()='Living']")
	public static WebElement living;
	//selecting chandliers
	@FindBy(xpath = "//a[@href='https://www.pepperfry.com/lamps-lighting-chandeliers.html?type=hover-living']")//*[@id="meta-living"]/div/div[7]/div[2]/div[1]/a
	public static WebElement Chandeliers;
	//filtering chandliers using type
	@FindBy(xpath="//a[@href='https://www.pepperfry.com/lamps-lighting-chandeliers.html?type=hover-living']")//a[@href='https://www.pepperfry.com/lamps-lighting-chandeliers.html?type=hover-living']
	public static WebElement ChandeliersType;
	//filtering with color
//	@FindBy(xpath="//*[@id=\"clipFilterCardContainer\"]/div[3]/div/div[1]/div/div[7]/div/h2")
//	public static WebElement color;
	@FindBy(xpath="//*[@id=\"mCSB_5_container\"]/li[12]/label")
	public static WebElement multiColor;
	//add to cart
	@FindBy(xpath="//*[@id=\"p_1_1_1856005\"]/div/div[1]/a/img")
	public static WebElement addToCartOver;
	@FindBy(xpath="//div[@class='row clip-prod-container']//div[@id='p_1_1_1856005']//div//div[1]//a[text()='Add To Cart']")
	public static WebElement addToCart;
	

}
