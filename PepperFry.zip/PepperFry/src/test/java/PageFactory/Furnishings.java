package PageFactory;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class Furnishings {
	@FindBy(linkText = "Furnishings")
	public static WebElement Furnishings1;
	@FindBy(xpath = "//a[normalize-space()='Organisers']")
	public static WebElement organisers;
	@FindBy(xpath="//label[@for='brandsnameMy_gift_booth']")
	public static WebElement brand;
	@FindBy(xpath="//label[@for='b_l_colorBlack']")
	public static WebElement color;
	@FindBy(xpath = "//label[@for='lidYes']")
	public static WebElement lid;
	@FindBy(xpath ="//div[@class='pf-col md-9 sm-8']//img[1]")
	public static WebElement add;
	@FindBy(xpath="//a[@class='clip-add-to-cart-btn']")
	public static WebElement addToCart;
	
	

}
