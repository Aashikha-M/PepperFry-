package PageFactory;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class KidsRoom {
	@FindBy(xpath="//ul//li[4]//a[text()='Kids Room']")
	public static WebElement kidsroom;
	
	@FindBy(xpath="//div//div[5]//a[text()='Sofas']")
	public static WebElement sofa;
	@FindBy(xpath="//img[@alt='Martys Sofa in Black Stripes Print Boingg!']")
	public static WebElement product;
	@FindBy(xpath="//img[@alt='Martys Sofa in Black Stripes Print Boingg!']")
	public static WebElement kids;
	@FindBy(xpath="//*[@id='p_15_1_1756894']/div/div[1]/div/a")//div[@id='p_13_1_1756894']//a[@class='clip-add-to-cart-btn'][normalize-space()='Add To Cart']")
	public static WebElement addToCart;
	
}//html[1]/body[1]/div[2]/div[2]/div[1]/div[2]/div[1]/div[2]/div[1]/div[1]/div[2]/div[1]/div[11]/div[1]/div[1]/a[1]
//*[@id='vipAddToCartButton']
