package PageFactory;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class Furniture {
	@FindBy(xpath="//div//ul//li//a[text()='Furniture']")
	public static WebElement furniture;
	@FindBy(xpath="//div//div[8]//a[text()='Dressing Tables']")
	public static WebElement	dressingTable;
	@FindBy(xpath="//label[text()='Home Centre']")
	public static WebElement brand;
	@FindBy(xpath="//label[@for='price10000-20000']")
	public static WebElement priceRange;
	@FindBy(xpath="//label[text()='10% and Above']")
	public static WebElement discount;
	//selecting the dressing table after filters
	@FindBy(xpath="//img[@alt='Rhine Dressing Table in Black Colour']")
	public static WebElement table;
	@FindBy(xpath="//div[@id='productView']//div[2]//a[text()='Add To Cart']")
	public static WebElement addToCart1;
}
