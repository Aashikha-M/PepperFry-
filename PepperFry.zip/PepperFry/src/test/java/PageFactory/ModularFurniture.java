package PageFactory;

import org.openqa.selenium.WebElement;

import org.openqa.selenium.support.FindBy;

public class ModularFurniture {
	@FindBy(xpath = "//ul//li[10]//a[text()='Modular Furniture']")
	public static WebElement modularFurniture;
	@FindBy(xpath= "//*[@id=\"meta-modularfurniture\"]/div/div/div/div/div[1]/a/span[1]/img")
	public static WebElement wardrobe;
	@FindBy(xpath="//img[@alt='Three Door Wardrobe with Dresser in PLPB']")
	public static WebElement wardrobeTable;
	@FindBy(xpath="//div[@class='look__qview-slide slick-initialized slick-slider']//div[2]//img[1]")
	               //div[@class='look__qview-slide-item slick-slide slick-current slick-active']//img[@alt='product'] 
	public static WebElement pose1;
	@FindBy(xpath="//div[@class='look__qview-slide-item slick-slide slick-current slick-active']//img[@alt='product']")
	               //div[@class='look__qview-slide-item slick-slide slick-current slick-active']//img[@alt='product']
	public static WebElement pose2;
	
}
