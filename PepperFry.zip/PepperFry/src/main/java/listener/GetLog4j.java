package listener;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
public class GetLog4j {
	public static Logger logs=Logger.getLogger(GetLog4j.class.getName());
	public static Logger getLog() {
	String conf="C:\\Users\\Aashikha\\eclipse-workspace\\PepperFry\\target\\Logs\\Log4jOutput\\log4jOutput.log";
	PropertyConfigurator.configure(conf);
	return logs;

}}
